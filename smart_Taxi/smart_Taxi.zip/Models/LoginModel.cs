﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MvcApplication2.Controllers
{
   public class LoginModel
    {
        public string Phone { get; set; }

        public string Password { get; set; }

        public string Name { get; set; }

        public string Surname { get; set; }

        public string Mail { get; set; }

        


    }
}
